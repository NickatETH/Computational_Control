from dataclasses import dataclass
from data import Data

@dataclass
class Labels(Data):

    n_regions : int