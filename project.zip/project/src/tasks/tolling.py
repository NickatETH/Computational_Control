from src.tasks.task import Task

class Tolling(Task):

    def __init__(self,taskparams):
        super.__init__(taskparams)
    
    def runtask():
        pass