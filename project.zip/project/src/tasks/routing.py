from src.tasks.task import Task

class Routing(Task):
    """Routing task."""
    
    def __init__(self, taskparams):
        super().__init__(taskparams=taskparams)
        
    def runtask(self):
        pass